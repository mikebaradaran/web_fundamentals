#---
# Database seed data for Web Designer Magazine Ruby on Rails tutorial
# Written by Matt Gifford (http://www.mattgifford.co.uk)
#---
# encoding: utf-8
Post.delete_all
Post.create(:title => 'Ruby on Rails Introduction',
  :content => 
    %{<p>In the first of a two-part tutorial, Matt Gifford will guide you through the initial 
		introduction to setting up and creating your first Ruby on Rails application.</p>}
)
# . . .
Post.create(:title => 'CSS3 - Gradients, Borders and Shadows. Oh my!',
  :content =>
    %{<p>CSS3 has changed the way we build and structure our web applications and layouts.
		Explore the rich visual enhancements provided by the new additions to the standard protocol.</p>}
)
# . . .
